import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Heart, Phone, Lock, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import MobileContainer from './MobileContainer';
import appIcon from '../assets/app_icon.png';

const LoginScreen = ({ onNavigate }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    const result = await login({ phone_number: phoneNumber, password });
    
    if (result.success) {
      onNavigate('dashboard');
    } else {
      setError(result.error || 'Login failed');
    }
    
    setIsLoading(false);
  };

  const handleDoctorLogin = () => {
    onNavigate('doctor-login');
  };

  return (
    <MobileContainer>
      <div className="flex flex-col min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
        {/* Header */}
        <div className="flex flex-col items-center pt-16 pb-8">
          <div className="w-24 h-24 mb-4 rounded-full bg-white shadow-lg flex items-center justify-center">
            <img src={appIcon} alt="CardioConnect" className="w-16 h-16 rounded-full" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">CardioConnect</h1>
          <p className="text-gray-600 text-center px-8">
            Your trusted partner for cardiac care with Dr. Zafar Iqbal
          </p>
        </div>

        {/* Login Form */}
        <div className="flex-1 px-6">
          <Card className="w-full max-w-sm mx-auto">
            <CardHeader className="text-center pb-4">
              <h2 className="text-xl font-semibold text-gray-800">Patient Login</h2>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                {error && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-red-600 text-sm">{error}</p>
                  </div>
                )}
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Phone Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      type="tel"
                      placeholder="03001234567"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-gray-400"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <Button 
                  type="submit" 
                  className="w-full cardiac-gradient text-white"
                  disabled={isLoading}
                >
                  {isLoading ? 'Signing In...' : 'Sign In'}
                </Button>
              </form>

              <div className="mt-4 text-center">
                <button 
                  onClick={() => onNavigate('forgot-password')}
                  className="text-sm text-blue-600 hover:underline"
                >
                  Forgot Password?
                </button>
              </div>

              <div className="mt-6 text-center">
                <p className="text-sm text-gray-600 mb-2">New Patient?</p>
                <Button 
                  variant="outline" 
                  onClick={() => onNavigate('register')}
                  className="w-full"
                >
                  Register Here
                </Button>
              </div>

              <div className="mt-6 pt-4 border-t border-gray-200">
                <Button 
                  variant="secondary" 
                  onClick={handleDoctorLogin}
                  className="w-full medical-gradient text-white"
                >
                  Doctor Login
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Demo Credentials */}
        <div className="px-6 pb-8">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="pt-4">
              <h3 className="font-medium text-blue-800 mb-2">Demo Credentials</h3>
              <p className="text-sm text-blue-700">
                Phone: 03001234567<br />
                Password: patient123
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </MobileContainer>
  );
};

export default LoginScreen;

