from flask import Blueprint, request, jsonify, session
from datetime import datetime, date
from src.models.base import db, Patient, Doctor
import re

auth_bp = Blueprint('auth', __name__)

def validate_phone_number(phone):
    """Validate Pakistani phone number format"""
    # Pakistani phone number patterns: +92XXXXXXXXXX, 03XXXXXXXXX, etc.
    pattern = r'^(\+92|0)?3[0-9]{9}$'
    return re.match(pattern, phone) is not None

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

@auth_bp.route('/register/patient', methods=['POST'])
def register_patient():
    """Register a new patient"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['full_name', 'phone_number', 'password']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate phone number format
        if not validate_phone_number(data['phone_number']):
            return jsonify({'error': 'Invalid phone number format'}), 400
        
        # Validate email if provided
        if data.get('email') and not validate_email(data['email']):
            return jsonify({'error': 'Invalid email format'}), 400
        
        # Check if patient already exists
        existing_patient = Patient.query.filter_by(phone_number=data['phone_number']).first()
        if existing_patient:
            return jsonify({'error': 'Patient with this phone number already exists'}), 409
        
        if data.get('email'):
            existing_email = Patient.query.filter_by(email=data['email']).first()
            if existing_email:
                return jsonify({'error': 'Patient with this email already exists'}), 409
        
        # Parse date of birth if provided
        date_of_birth = None
        if data.get('date_of_birth'):
            try:
                date_of_birth = datetime.strptime(data['date_of_birth'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
        
        # Create new patient
        patient = Patient(
            full_name=data['full_name'],
            phone_number=data['phone_number'],
            email=data.get('email'),
            date_of_birth=date_of_birth,
            emergency_contact_name=data.get('emergency_contact_name'),
            emergency_contact_phone=data.get('emergency_contact_phone'),
            blood_group=data.get('blood_group'),
            allergies=data.get('allergies'),
            medical_history=data.get('medical_history'),
            current_medications=data.get('current_medications')
        )
        
        patient.set_password(data['password'])
        
        db.session.add(patient)
        db.session.commit()
        
        # Create session
        session['user_id'] = patient.id
        session['user_type'] = 'patient'
        
        return jsonify({
            'message': 'Patient registered successfully',
            'patient': patient.to_dict_safe()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/login/patient', methods=['POST'])
def login_patient():
    """Login patient"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('phone_number') or not data.get('password'):
            return jsonify({'error': 'Phone number and password are required'}), 400
        
        # Find patient
        patient = Patient.query.filter_by(phone_number=data['phone_number']).first()
        
        if not patient or not patient.check_password(data['password']):
            return jsonify({'error': 'Invalid phone number or password'}), 401
        
        if not patient.is_active:
            return jsonify({'error': 'Account is deactivated'}), 401
        
        # Create session
        session['user_id'] = patient.id
        session['user_type'] = 'patient'
        
        return jsonify({
            'message': 'Login successful',
            'patient': patient.to_dict_safe()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/login/doctor', methods=['POST'])
def login_doctor():
    """Login doctor (admin)"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email and password are required'}), 400
        
        # Find doctor
        doctor = Doctor.query.filter_by(email=data['email']).first()
        
        if not doctor or not doctor.check_password(data['password']):
            return jsonify({'error': 'Invalid email or password'}), 401
        
        if not doctor.is_active:
            return jsonify({'error': 'Account is deactivated'}), 401
        
        # Create session
        session['user_id'] = doctor.id
        session['user_type'] = 'doctor'
        
        return jsonify({
            'message': 'Login successful',
            'doctor': doctor.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    """Logout user"""
    session.clear()
    return jsonify({'message': 'Logout successful'}), 200

@auth_bp.route('/me', methods=['GET'])
def get_current_user():
    """Get current logged-in user information"""
    try:
        if 'user_id' not in session or 'user_type' not in session:
            return jsonify({'error': 'Not authenticated'}), 401
        
        user_id = session['user_id']
        user_type = session['user_type']
        
        if user_type == 'patient':
            patient = Patient.query.get(user_id)
            if not patient:
                session.clear()
                return jsonify({'error': 'User not found'}), 404
            return jsonify({
                'user_type': 'patient',
                'user': patient.to_dict_safe()
            }), 200
            
        elif user_type == 'doctor':
            doctor = Doctor.query.get(user_id)
            if not doctor:
                session.clear()
                return jsonify({'error': 'User not found'}), 404
            return jsonify({
                'user_type': 'doctor',
                'user': doctor.to_dict()
            }), 200
        
        else:
            session.clear()
            return jsonify({'error': 'Invalid user type'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/change-password', methods=['POST'])
def change_password():
    """Change user password"""
    try:
        if 'user_id' not in session or 'user_type' not in session:
            return jsonify({'error': 'Not authenticated'}), 401
        
        data = request.get_json()
        
        if not data.get('current_password') or not data.get('new_password'):
            return jsonify({'error': 'Current password and new password are required'}), 400
        
        user_id = session['user_id']
        user_type = session['user_type']
        
        if user_type == 'patient':
            user = Patient.query.get(user_id)
        elif user_type == 'doctor':
            user = Doctor.query.get(user_id)
        else:
            return jsonify({'error': 'Invalid user type'}), 400
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        if not user.check_password(data['current_password']):
            return jsonify({'error': 'Current password is incorrect'}), 400
        
        user.set_password(data['new_password'])
        db.session.commit()
        
        return jsonify({'message': 'Password changed successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

