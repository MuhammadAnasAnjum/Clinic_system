from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class Doctor(db.Model):
    __tablename__ = 'doctors'
    
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    
    # Professional information
    qualifications = db.Column(db.String(200), nullable=False)  # e.g., "MBBS, FCPS"
    specializations = db.Column(db.Text, nullable=False)  # e.g., "Blood pressure, heart conditions, cardiography, angioplasty"
    license_number = db.Column(db.String(50), nullable=False)
    experience_years = db.Column(db.Integer, nullable=True)
    
    # Institution information
    affiliated_institution = db.Column(db.String(200), nullable=True)  # e.g., "Punjab Institute of Cardiology, Lahore"
    
    # Profile information
    profile_photo_url = db.Column(db.String(500), nullable=True)
    bio = db.Column(db.Text, nullable=True)
    consultation_fee = db.Column(db.Float, nullable=False, default=2000.0)  # PKR
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    is_available_online = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships - using string references to avoid circular imports
    appointments = db.relationship('Appointment', backref='doctor', lazy=True)
    clinic_schedules = db.relationship('ClinicSchedule', backref='doctor', lazy=True)
    medical_records = db.relationship('MedicalRecord', backref='doctor', lazy=True)
    
    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password against hash"""
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self):
        """Convert doctor object to dictionary"""
        return {
            'id': self.id,
            'full_name': self.full_name,
            'email': self.email,
            'phone_number': self.phone_number,
            'qualifications': self.qualifications,
            'specializations': self.specializations,
            'license_number': self.license_number,
            'experience_years': self.experience_years,
            'affiliated_institution': self.affiliated_institution,
            'profile_photo_url': self.profile_photo_url,
            'bio': self.bio,
            'consultation_fee': self.consultation_fee,
            'is_active': self.is_active,
            'is_available_online': self.is_available_online,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
    
    def to_dict_public(self):
        """Convert doctor object to dictionary for public display"""
        return {
            'id': self.id,
            'full_name': self.full_name,
            'qualifications': self.qualifications,
            'specializations': self.specializations,
            'experience_years': self.experience_years,
            'affiliated_institution': self.affiliated_institution,
            'profile_photo_url': self.profile_photo_url,
            'bio': self.bio,
            'consultation_fee': self.consultation_fee,
            'is_available_online': self.is_available_online
        }
    
    def __repr__(self):
        return f'<Doctor {self.full_name}>'


class ClinicSchedule(db.Model):
    __tablename__ = 'clinic_schedules'
    
    id = db.Column(db.Integer, primary_key=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=False)
    
    # Clinic information
    clinic_name = db.Column(db.String(100), nullable=False)  # e.g., "Lifeline Clinic"
    clinic_address = db.Column(db.String(200), nullable=False)  # e.g., "Jail Road, Sahiwal"
    
    # Schedule information
    day_of_week = db.Column(db.Integer, nullable=False)  # 0=Monday, 6=Sunday
    start_time = db.Column(db.Time, nullable=False)  # e.g., 14:00 for 2 PM
    end_time = db.Column(db.Time, nullable=False)  # e.g., 17:00 for 5 PM
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert clinic schedule to dictionary"""
        return {
            'id': self.id,
            'doctor_id': self.doctor_id,
            'clinic_name': self.clinic_name,
            'clinic_address': self.clinic_address,
            'day_of_week': self.day_of_week,
            'start_time': self.start_time.strftime('%H:%M'),
            'end_time': self.end_time.strftime('%H:%M'),
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat()
        }
    
    def __repr__(self):
        return f'<ClinicSchedule {self.clinic_name} - {self.day_of_week}>'

