from flask import Blueprint, request, jsonify, session
from datetime import datetime, date, time, timedelta
from src.models.base import db, Appointment, AppointmentSlot, Patient, Doctor, AppointmentStatus, AppointmentType, PaymentStatus
import uuid

appointments_bp = Blueprint('appointments', __name__)

def require_auth(user_type=None):
    """Decorator to require authentication"""
    def decorator(f):
        def wrapper(*args, **kwargs):
            if 'user_id' not in session or 'user_type' not in session:
                return jsonify({'error': 'Authentication required'}), 401
            
            if user_type and session['user_type'] != user_type:
                return jsonify({'error': 'Insufficient permissions'}), 403
            
            return f(*args, **kwargs)
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator

@appointments_bp.route('/available-slots', methods=['GET'])
def get_available_slots():
    """Get available appointment slots for a doctor"""
    try:
        doctor_id = request.args.get('doctor_id', type=int)
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        appointment_type = request.args.get('type', 'in_person')
        
        if not doctor_id:
            return jsonify({'error': 'doctor_id is required'}), 400
        
        # Default to next 30 days if dates not provided
        if not start_date:
            start_date = date.today()
        else:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        
        if not end_date:
            end_date = start_date + timedelta(days=30)
        else:
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        # Get available slots
        slots_query = AppointmentSlot.query.filter(
            AppointmentSlot.doctor_id == doctor_id,
            AppointmentSlot.slot_date >= start_date,
            AppointmentSlot.slot_date <= end_date,
            AppointmentSlot.is_available == True,
            AppointmentSlot.is_blocked == False
        )
        
        # Filter by appointment type
        if appointment_type == 'telemedicine':
            slots_query = slots_query.filter(AppointmentSlot.allows_telemedicine == True)
        else:
            slots_query = slots_query.filter(AppointmentSlot.allows_in_person == True)
        
        slots = slots_query.order_by(AppointmentSlot.slot_date, AppointmentSlot.slot_time).all()
        
        return jsonify({
            'slots': [slot.to_dict() for slot in slots]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@appointments_bp.route('/book', methods=['POST'])
@require_auth('patient')
def book_appointment():
    """Book a new appointment"""
    try:
        data = request.get_json()
        patient_id = session['user_id']
        
        # Validate required fields
        required_fields = ['doctor_id', 'appointment_date', 'appointment_time', 'appointment_type']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Parse date and time
        try:
            appointment_date = datetime.strptime(data['appointment_date'], '%Y-%m-%d').date()
            appointment_time = datetime.strptime(data['appointment_time'], '%H:%M').time()
        except ValueError:
            return jsonify({'error': 'Invalid date or time format'}), 400
        
        # Validate appointment type
        try:
            appointment_type = AppointmentType(data['appointment_type'])
        except ValueError:
            return jsonify({'error': 'Invalid appointment type'}), 400
        
        # Check if doctor exists
        doctor = Doctor.query.get(data['doctor_id'])
        if not doctor:
            return jsonify({'error': 'Doctor not found'}), 404
        
        # Check if slot is available
        slot = AppointmentSlot.query.filter(
            AppointmentSlot.doctor_id == data['doctor_id'],
            AppointmentSlot.slot_date == appointment_date,
            AppointmentSlot.slot_time == appointment_time,
            AppointmentSlot.is_available == True,
            AppointmentSlot.is_blocked == False
        ).first()
        
        if not slot:
            return jsonify({'error': 'Selected time slot is not available'}), 400
        
        # Check appointment type availability
        if appointment_type == AppointmentType.TELEMEDICINE and not slot.allows_telemedicine:
            return jsonify({'error': 'Telemedicine not available for this slot'}), 400
        elif appointment_type == AppointmentType.IN_PERSON and not slot.allows_in_person:
            return jsonify({'error': 'In-person appointment not available for this slot'}), 400
        
        # Check for existing appointment at the same time
        existing_appointment = Appointment.query.filter(
            Appointment.doctor_id == data['doctor_id'],
            Appointment.appointment_date == appointment_date,
            Appointment.appointment_time == appointment_time,
            Appointment.status.in_([AppointmentStatus.SCHEDULED, AppointmentStatus.CONFIRMED])
        ).first()
        
        if existing_appointment:
            return jsonify({'error': 'Time slot already booked'}), 409
        
        # Create appointment
        appointment = Appointment(
            patient_id=patient_id,
            doctor_id=data['doctor_id'],
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            appointment_type=appointment_type,
            duration_minutes=data.get('duration_minutes', 30),
            clinic_name=slot.clinic_name if appointment_type == AppointmentType.IN_PERSON else None,
            clinic_address=slot.clinic_address if appointment_type == AppointmentType.IN_PERSON else None,
            chief_complaint=data.get('chief_complaint'),
            symptoms=data.get('symptoms'),
            notes=data.get('notes'),
            consultation_fee=doctor.consultation_fee
        )
        
        # Generate video call room for telemedicine
        if appointment_type == AppointmentType.TELEMEDICINE:
            appointment.video_call_room_id = str(uuid.uuid4())
            appointment.video_call_link = f"/video-call/{appointment.video_call_room_id}"
        
        db.session.add(appointment)
        
        # Mark slot as unavailable
        slot.is_available = False
        
        db.session.commit()
        
        return jsonify({
            'message': 'Appointment booked successfully',
            'appointment': appointment.to_dict_with_details()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@appointments_bp.route('/my-appointments', methods=['GET'])
@require_auth('patient')
def get_patient_appointments():
    """Get patient's appointments"""
    try:
        patient_id = session['user_id']
        status = request.args.get('status')
        
        query = Appointment.query.filter(Appointment.patient_id == patient_id)
        
        if status:
            try:
                status_enum = AppointmentStatus(status)
                query = query.filter(Appointment.status == status_enum)
            except ValueError:
                return jsonify({'error': 'Invalid status'}), 400
        
        appointments = query.order_by(Appointment.appointment_date.desc(), Appointment.appointment_time.desc()).all()
        
        return jsonify({
            'appointments': [appointment.to_dict_with_details() for appointment in appointments]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@appointments_bp.route('/doctor-appointments', methods=['GET'])
@require_auth('doctor')
def get_doctor_appointments():
    """Get doctor's appointments"""
    try:
        doctor_id = session['user_id']
        status = request.args.get('status')
        date_filter = request.args.get('date')
        
        query = Appointment.query.filter(Appointment.doctor_id == doctor_id)
        
        if status:
            try:
                status_enum = AppointmentStatus(status)
                query = query.filter(Appointment.status == status_enum)
            except ValueError:
                return jsonify({'error': 'Invalid status'}), 400
        
        if date_filter:
            try:
                filter_date = datetime.strptime(date_filter, '%Y-%m-%d').date()
                query = query.filter(Appointment.appointment_date == filter_date)
            except ValueError:
                return jsonify({'error': 'Invalid date format'}), 400
        
        appointments = query.order_by(Appointment.appointment_date, Appointment.appointment_time).all()
        
        return jsonify({
            'appointments': [appointment.to_dict_with_details() for appointment in appointments]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@appointments_bp.route('/<int:appointment_id>', methods=['GET'])
@require_auth()
def get_appointment_details():
    """Get appointment details"""
    try:
        appointment = Appointment.query.get(appointment_id)
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        user_id = session['user_id']
        user_type = session['user_type']
        
        # Check permissions
        if user_type == 'patient' and appointment.patient_id != user_id:
            return jsonify({'error': 'Access denied'}), 403
        elif user_type == 'doctor' and appointment.doctor_id != user_id:
            return jsonify({'error': 'Access denied'}), 403
        
        return jsonify({
            'appointment': appointment.to_dict_with_details()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@appointments_bp.route('/<int:appointment_id>/cancel', methods=['POST'])
@require_auth()
def cancel_appointment():
    """Cancel an appointment"""
    try:
        appointment = Appointment.query.get(appointment_id)
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        user_id = session['user_id']
        user_type = session['user_type']
        
        # Check permissions
        if user_type == 'patient' and appointment.patient_id != user_id:
            return jsonify({'error': 'Access denied'}), 403
        elif user_type == 'doctor' and appointment.doctor_id != user_id:
            return jsonify({'error': 'Access denied'}), 403
        
        # Check if appointment can be cancelled
        if appointment.status in [AppointmentStatus.COMPLETED, AppointmentStatus.CANCELLED]:
            return jsonify({'error': 'Cannot cancel this appointment'}), 400
        
        data = request.get_json() or {}
        
        # Update appointment
        appointment.status = AppointmentStatus.CANCELLED
        appointment.cancelled_at = datetime.utcnow()
        appointment.cancellation_reason = data.get('reason')
        appointment.cancelled_by = user_type
        
        # Make slot available again
        slot = AppointmentSlot.query.filter(
            AppointmentSlot.doctor_id == appointment.doctor_id,
            AppointmentSlot.slot_date == appointment.appointment_date,
            AppointmentSlot.slot_time == appointment.appointment_time
        ).first()
        
        if slot:
            slot.is_available = True
        
        db.session.commit()
        
        return jsonify({
            'message': 'Appointment cancelled successfully',
            'appointment': appointment.to_dict_with_details()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@appointments_bp.route('/<int:appointment_id>/status', methods=['PUT'])
@require_auth('doctor')
def update_appointment_status():
    """Update appointment status (doctor only)"""
    try:
        appointment = Appointment.query.get(appointment_id)
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        doctor_id = session['user_id']
        if appointment.doctor_id != doctor_id:
            return jsonify({'error': 'Access denied'}), 403
        
        data = request.get_json()
        if not data.get('status'):
            return jsonify({'error': 'Status is required'}), 400
        
        try:
            new_status = AppointmentStatus(data['status'])
        except ValueError:
            return jsonify({'error': 'Invalid status'}), 400
        
        appointment.status = new_status
        db.session.commit()
        
        return jsonify({
            'message': 'Appointment status updated successfully',
            'appointment': appointment.to_dict_with_details()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

