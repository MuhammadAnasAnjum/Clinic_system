from flask import Blueprint, request, jsonify, session
from datetime import datetime, date, time, timedelta
from src.models.base import db, Doctor, ClinicSchedule, AppointmentSlot, Appointment, AppointmentStatus
from sqlalchemy import func

doctors_bp = Blueprint('doctors', __name__)

def require_auth(user_type=None):
    """Decorator to require authentication"""
    def decorator(f):
        def wrapper(*args, **kwargs):
            if 'user_id' not in session or 'user_type' not in session:
                return jsonify({'error': 'Authentication required'}), 401
            
            if user_type and session['user_type'] != user_type:
                return jsonify({'error': 'Insufficient permissions'}), 403
            
            return f(*args, **kwargs)
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator

@doctors_bp.route('/', methods=['GET'])
def get_doctors():
    """Get list of all active doctors"""
    try:
        doctors = Doctor.query.filter(Doctor.is_active == True).all()
        return jsonify({
            'doctors': [doctor.to_dict_public() for doctor in doctors]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@doctors_bp.route('/<int:doctor_id>', methods=['GET'])
def get_doctor_details():
    """Get doctor details by ID"""
    try:
        doctor = Doctor.query.get(doctor_id)
        if not doctor or not doctor.is_active:
            return jsonify({'error': 'Doctor not found'}), 404
        
        # Get clinic schedules
        schedules = ClinicSchedule.query.filter(
            ClinicSchedule.doctor_id == doctor_id,
            ClinicSchedule.is_active == True
        ).order_by(ClinicSchedule.day_of_week, ClinicSchedule.start_time).all()
        
        doctor_data = doctor.to_dict_public()
        doctor_data['clinic_schedules'] = [schedule.to_dict() for schedule in schedules]
        
        return jsonify({
            'doctor': doctor_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@doctors_bp.route('/profile', methods=['GET'])
@require_auth('doctor')
def get_doctor_profile():
    """Get current doctor's profile"""
    try:
        doctor_id = session['user_id']
        doctor = Doctor.query.get(doctor_id)
        
        if not doctor:
            return jsonify({'error': 'Doctor not found'}), 404
        
        # Get clinic schedules
        schedules = ClinicSchedule.query.filter(
            ClinicSchedule.doctor_id == doctor_id,
            ClinicSchedule.is_active == True
        ).order_by(ClinicSchedule.day_of_week, ClinicSchedule.start_time).all()
        
        doctor_data = doctor.to_dict()
        doctor_data['clinic_schedules'] = [schedule.to_dict() for schedule in schedules]
        
        return jsonify({
            'doctor': doctor_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@doctors_bp.route('/profile', methods=['PUT'])
@require_auth('doctor')
def update_doctor_profile():
    """Update doctor profile"""
    try:
        doctor_id = session['user_id']
        doctor = Doctor.query.get(doctor_id)
        
        if not doctor:
            return jsonify({'error': 'Doctor not found'}), 404
        
        data = request.get_json()
        
        # Update allowed fields
        updatable_fields = [
            'phone_number', 'bio', 'consultation_fee', 
            'is_available_online', 'profile_photo_url'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(doctor, field, data[field])
        
        doctor.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Profile updated successfully',
            'doctor': doctor.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@doctors_bp.route('/availability', methods=['GET'])
@require_auth('doctor')
def get_doctor_availability():
    """Get doctor's availability slots"""
    try:
        doctor_id = session['user_id']
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # Default to next 30 days if dates not provided
        if not start_date:
            start_date = date.today()
        else:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        
        if not end_date:
            end_date = start_date + timedelta(days=30)
        else:
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        slots = AppointmentSlot.query.filter(
            AppointmentSlot.doctor_id == doctor_id,
            AppointmentSlot.slot_date >= start_date,
            AppointmentSlot.slot_date <= end_date
        ).order_by(AppointmentSlot.slot_date, AppointmentSlot.slot_time).all()
        
        return jsonify({
            'slots': [slot.to_dict() for slot in slots]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@doctors_bp.route('/availability/generate', methods=['POST'])
@require_auth('doctor')
def generate_availability_slots():
    """Generate availability slots based on clinic schedules"""
    try:
        doctor_id = session['user_id']
        data = request.get_json()
        
        start_date = datetime.strptime(data['start_date'], '%Y-%m-%d').date()
        end_date = datetime.strptime(data['end_date'], '%Y-%m-%d').date()
        slot_duration = data.get('slot_duration', 30)  # minutes
        
        # Get clinic schedules
        schedules = ClinicSchedule.query.filter(
            ClinicSchedule.doctor_id == doctor_id,
            ClinicSchedule.is_active == True
        ).all()
        
        if not schedules:
            return jsonify({'error': 'No clinic schedules found'}), 400
        
        slots_created = 0
        current_date = start_date
        
        while current_date <= end_date:
            day_of_week = current_date.weekday()  # 0=Monday, 6=Sunday
            
            # Find schedules for this day
            day_schedules = [s for s in schedules if s.day_of_week == day_of_week]
            
            for schedule in day_schedules:
                # Generate slots for this schedule
                current_time = datetime.combine(current_date, schedule.start_time)
                end_time = datetime.combine(current_date, schedule.end_time)
                
                while current_time + timedelta(minutes=slot_duration) <= end_time:
                    # Check if slot already exists
                    existing_slot = AppointmentSlot.query.filter(
                        AppointmentSlot.doctor_id == doctor_id,
                        AppointmentSlot.slot_date == current_date,
                        AppointmentSlot.slot_time == current_time.time()
                    ).first()
                    
                    if not existing_slot:
                        slot = AppointmentSlot(
                            doctor_id=doctor_id,
                            slot_date=current_date,
                            slot_time=current_time.time(),
                            duration_minutes=slot_duration,
                            clinic_name=schedule.clinic_name,
                            clinic_address=schedule.clinic_address,
                            allows_in_person=True,
                            allows_telemedicine=True
                        )
                        db.session.add(slot)
                        slots_created += 1
                    
                    current_time += timedelta(minutes=slot_duration)
            
            current_date += timedelta(days=1)
        
        db.session.commit()
        
        return jsonify({
            'message': f'{slots_created} availability slots generated successfully'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@doctors_bp.route('/availability/<int:slot_id>/block', methods=['POST'])
@require_auth('doctor')
def block_availability_slot():
    """Block an availability slot"""
    try:
        doctor_id = session['user_id']
        slot = AppointmentSlot.query.get(slot_id)
        
        if not slot or slot.doctor_id != doctor_id:
            return jsonify({'error': 'Slot not found'}), 404
        
        data = request.get_json() or {}
        
        slot.is_blocked = True
        slot.is_available = False
        slot.block_reason = data.get('reason', 'Blocked by doctor')
        
        db.session.commit()
        
        return jsonify({
            'message': 'Slot blocked successfully',
            'slot': slot.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@doctors_bp.route('/availability/<int:slot_id>/unblock', methods=['POST'])
@require_auth('doctor')
def unblock_availability_slot():
    """Unblock an availability slot"""
    try:
        doctor_id = session['user_id']
        slot = AppointmentSlot.query.get(slot_id)
        
        if not slot or slot.doctor_id != doctor_id:
            return jsonify({'error': 'Slot not found'}), 404
        
        # Check if slot has an appointment
        appointment = Appointment.query.filter(
            Appointment.doctor_id == doctor_id,
            Appointment.appointment_date == slot.slot_date,
            Appointment.appointment_time == slot.slot_time,
            Appointment.status.in_([AppointmentStatus.SCHEDULED, AppointmentStatus.CONFIRMED])
        ).first()
        
        slot.is_blocked = False
        slot.block_reason = None
        slot.is_available = appointment is None
        
        db.session.commit()
        
        return jsonify({
            'message': 'Slot unblocked successfully',
            'slot': slot.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@doctors_bp.route('/dashboard/stats', methods=['GET'])
@require_auth('doctor')
def get_dashboard_stats():
    """Get dashboard statistics for doctor"""
    try:
        doctor_id = session['user_id']
        today = date.today()
        
        # Today's appointments
        todays_appointments = Appointment.query.filter(
            Appointment.doctor_id == doctor_id,
            Appointment.appointment_date == today,
            Appointment.status.in_([AppointmentStatus.SCHEDULED, AppointmentStatus.CONFIRMED, AppointmentStatus.IN_PROGRESS])
        ).count()
        
        # Pending consultations
        pending_consultations = Appointment.query.filter(
            Appointment.doctor_id == doctor_id,
            Appointment.status == AppointmentStatus.SCHEDULED
        ).count()
        
        # Total patients (unique)
        total_patients = db.session.query(func.count(func.distinct(Appointment.patient_id))).filter(
            Appointment.doctor_id == doctor_id
        ).scalar()
        
        # Revenue this month
        start_of_month = today.replace(day=1)
        revenue_this_month = db.session.query(func.sum(Appointment.consultation_fee)).filter(
            Appointment.doctor_id == doctor_id,
            Appointment.appointment_date >= start_of_month,
            Appointment.payment_status == 'paid'
        ).scalar() or 0
        
        # Upcoming appointments (next 5)
        upcoming_appointments = Appointment.query.filter(
            Appointment.doctor_id == doctor_id,
            Appointment.status.in_([AppointmentStatus.SCHEDULED, AppointmentStatus.CONFIRMED]),
            Appointment.appointment_date >= today
        ).order_by(Appointment.appointment_date, Appointment.appointment_time).limit(5).all()
        
        return jsonify({
            'stats': {
                'todays_appointments': todays_appointments,
                'pending_consultations': pending_consultations,
                'total_patients': total_patients,
                'revenue_this_month': revenue_this_month
            },
            'upcoming_appointments': [appointment.to_dict_with_details() for appointment in upcoming_appointments]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

