#!/usr/bin/env python3
"""
Simple seed data script for CardioConnect application
"""

import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from datetime import datetime, date, time, timedelta
from src.main import app
from src.models.doctor import db, Doctor, ClinicSchedule
from src.models.patient import Patient

def main():
    """Main function to seed the database"""
    with app.app_context():
        print("Starting simple database seeding...")
        
        # Check if doctor already exists
        existing_doctor = Doctor.query.filter_by(email="dr.zafar.iqbal@cardioconnect.pk").first()
        if existing_doctor:
            print("Doctor already exists. Skipping seeding.")
            return
        
        try:
            # Create doctor
            print("Creating doctor profile...")
            doctor = Doctor(
                full_name="Dr. Zafar Iqbal",
                email="dr.zafar.iqbal@cardioconnect.pk",
                phone_number="+923001234567",
                qualifications="MBBS, FCPS (Cardiologist)",
                specializations="Blood pressure, heart conditions, cardiography, angioplasty",
                license_number="PMC-12345-CARDIO",
                experience_years=15,
                affiliated_institution="Punjab Institute of Cardiology, Lahore",
                bio="Dr. Zafar Iqbal is a highly experienced cardiologist with over 15 years of practice.",
                consultation_fee=2000.0,
                is_active=True,
                is_available_online=True
            )
            doctor.set_password("admin123")
            db.session.add(doctor)
            db.session.flush()
            
            # Create clinic schedules
            print("Creating clinic schedules...")
            schedules = [
                # Lifeline Clinic - Monday to Friday, 2 PM - 5 PM
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Lifeline Clinic",
                    clinic_address="Jail Road, Sahiwal",
                    day_of_week=0, start_time=time(14, 0), end_time=time(17, 0)
                ),
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Lifeline Clinic",
                    clinic_address="Jail Road, Sahiwal",
                    day_of_week=1, start_time=time(14, 0), end_time=time(17, 0)
                ),
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Lifeline Clinic",
                    clinic_address="Jail Road, Sahiwal",
                    day_of_week=2, start_time=time(14, 0), end_time=time(17, 0)
                ),
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Lifeline Clinic",
                    clinic_address="Jail Road, Sahiwal",
                    day_of_week=3, start_time=time(14, 0), end_time=time(17, 0)
                ),
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Lifeline Clinic",
                    clinic_address="Jail Road, Sahiwal",
                    day_of_week=4, start_time=time(14, 0), end_time=time(17, 0)
                ),
                # Care Hospital - Monday to Saturday, 5 PM - 9 PM
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Care Hospital",
                    clinic_address="Bhindari Chowk, Sahiwal",
                    day_of_week=0, start_time=time(17, 0), end_time=time(21, 0)
                ),
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Care Hospital",
                    clinic_address="Bhindari Chowk, Sahiwal",
                    day_of_week=1, start_time=time(17, 0), end_time=time(21, 0)
                ),
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Care Hospital",
                    clinic_address="Bhindari Chowk, Sahiwal",
                    day_of_week=2, start_time=time(17, 0), end_time=time(21, 0)
                ),
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Care Hospital",
                    clinic_address="Bhindari Chowk, Sahiwal",
                    day_of_week=3, start_time=time(17, 0), end_time=time(21, 0)
                ),
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Care Hospital",
                    clinic_address="Bhindari Chowk, Sahiwal",
                    day_of_week=4, start_time=time(17, 0), end_time=time(21, 0)
                ),
                ClinicSchedule(
                    doctor_id=doctor.id,
                    clinic_name="Care Hospital",
                    clinic_address="Bhindari Chowk, Sahiwal",
                    day_of_week=5, start_time=time(17, 0), end_time=time(21, 0)
                )
            ]
            
            for schedule in schedules:
                db.session.add(schedule)
            
            # Create sample patients
            print("Creating sample patients...")
            patients_data = [
                {
                    'full_name': 'Ahmed Khan',
                    'phone_number': '03001234567',
                    'email': 'ahmed.khan@email.com',
                    'date_of_birth': date(1980, 5, 15),
                    'blood_group': 'B+'
                },
                {
                    'full_name': 'Fatima Ali',
                    'phone_number': '03009876543',
                    'email': 'fatima.ali@email.com',
                    'date_of_birth': date(1975, 8, 22),
                    'blood_group': 'A+'
                }
            ]
            
            for patient_data in patients_data:
                patient = Patient(**patient_data)
                patient.set_password('patient123')
                db.session.add(patient)
            
            db.session.commit()
            
            print("Simple database seeding completed successfully!")
            print(f"Doctor created: {doctor.full_name}")
            print(f"Clinic schedules created: {len(schedules)}")
            print(f"Sample patients created: {len(patients_data)}")
            print("\nLogin credentials:")
            print("Doctor (Admin): dr.zafar.iqbal@cardioconnect.pk / admin123")
            print("Sample Patient: 03001234567 / patient123")
            
        except Exception as e:
            db.session.rollback()
            print(f"Error during seeding: {str(e)}")
            raise

if __name__ == '__main__':
    main()

