import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  MapPin, 
  Star,
  Heart,
  Video,
  User
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import MobileContainer from './MobileContainer';

const BookAppointmentScreen = ({ onNavigate }) => {
  const { API_BASE } = useAuth();
  const [doctor, setDoctor] = useState(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [appointmentType, setAppointmentType] = useState('in_person');
  const [selectedClinic, setSelectedClinic] = useState('');
  const [availableSlots, setAvailableSlots] = useState([]);
  const [formData, setFormData] = useState({
    chief_complaint: '',
    symptoms: '',
    notes: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState(1); // 1: Doctor Info, 2: Date/Time, 3: Details, 4: Confirmation

  useEffect(() => {
    fetchDoctorInfo();
  }, []);

  useEffect(() => {
    if (selectedDate) {
      fetchAvailableSlots();
    }
  }, [selectedDate, appointmentType]);

  const fetchDoctorInfo = async () => {
    try {
      const response = await fetch(`${API_BASE}/doctors/`, {
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.doctors && data.doctors.length > 0) {
          setDoctor(data.doctors[0]); // Dr. Zafar Iqbal
        }
      }
    } catch (error) {
      console.error('Failed to fetch doctor info:', error);
    }
  };

  const fetchAvailableSlots = async () => {
    try {
      const response = await fetch(
        `${API_BASE}/appointments/available-slots?doctor_id=${doctor?.id}&start_date=${selectedDate}&end_date=${selectedDate}&type=${appointmentType}`,
        { credentials: 'include' }
      );
      
      if (response.ok) {
        const data = await response.json();
        setAvailableSlots(data.slots || []);
      }
    } catch (error) {
      console.error('Failed to fetch available slots:', error);
    }
  };

  const handleBookAppointment = async () => {
    setIsLoading(true);
    
    try {
      const appointmentData = {
        doctor_id: doctor.id,
        appointment_date: selectedDate,
        appointment_time: selectedTime,
        appointment_type: appointmentType,
        clinic_name: selectedClinic,
        ...formData
      };

      const response = await fetch(`${API_BASE}/appointments/book`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(appointmentData),
      });

      if (response.ok) {
        const data = await response.json();
        onNavigate('payment', { appointmentId: data.appointment.id });
      } else {
        const errorData = await response.json();
        alert(errorData.error || 'Failed to book appointment');
      }
    } catch (error) {
      alert('Network error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  const getMaxDate = () => {
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 30);
    return maxDate.toISOString().split('T')[0];
  };

  const timeSlots = [
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30',
    '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30'
  ];

  const clinics = [
    { name: 'Lifeline Clinic', address: 'Jail Road, Sahiwal', hours: '2 PM - 5 PM' },
    { name: 'Care Hospital', address: 'Bhindari Chowk, Sahiwal', hours: '5 PM - 9 PM' }
  ];

  if (!doctor) {
    return (
      <MobileContainer>
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <Heart className="h-8 w-8 text-red-600 mx-auto mb-4 heart-pulse" />
            <p className="text-gray-600">Loading doctor information...</p>
          </div>
        </div>
      </MobileContainer>
    );
  }

  return (
    <MobileContainer>
      <div className="flex flex-col min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm p-4">
          <div className="flex items-center">
            <button 
              onClick={() => step > 1 ? setStep(step - 1) : onNavigate('dashboard')}
              className="p-2 rounded-full hover:bg-gray-100"
            >
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </button>
            <h1 className="flex-1 text-center text-lg font-semibold text-gray-800 pr-9">
              Book Appointment
            </h1>
          </div>
          
          {/* Progress Indicator */}
          <div className="flex items-center justify-center mt-4 space-x-2">
            {[1, 2, 3, 4].map((stepNum) => (
              <div
                key={stepNum}
                className={`w-2 h-2 rounded-full ${
                  stepNum <= step ? 'bg-red-600' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 p-4 overflow-y-auto">
          {step === 1 && (
            <div className="space-y-6">
              {/* Doctor Profile */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center">
                      <User className="h-8 w-8 text-red-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg text-gray-800">{doctor.full_name}</h3>
                      <p className="text-sm text-gray-600">{doctor.qualifications}</p>
                      <div className="flex items-center mt-1">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="text-sm text-gray-600 ml-1">4.9 (245 reviews)</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <h4 className="font-medium text-gray-800 mb-2">Specializations</h4>
                    <p className="text-sm text-gray-600">{doctor.specializations}</p>
                  </div>
                  
                  <div className="mt-4">
                    <h4 className="font-medium text-gray-800 mb-2">Experience</h4>
                    <p className="text-sm text-gray-600">{doctor.experience_years} years</p>
                  </div>
                  
                  <div className="mt-4">
                    <h4 className="font-medium text-gray-800 mb-2">Institution</h4>
                    <p className="text-sm text-gray-600">{doctor.affiliated_institution}</p>
                  </div>
                  
                  <div className="mt-4 p-3 bg-green-50 rounded-lg">
                    <p className="text-sm font-medium text-green-800">
                      Consultation Fee: PKR {doctor.consultation_fee}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Appointment Type Selection */}
              <Card>
                <CardHeader>
                  <h3 className="font-semibold text-gray-800">Select Consultation Type</h3>
                </CardHeader>
                <CardContent className="space-y-3">
                  <button
                    onClick={() => setAppointmentType('in_person')}
                    className={`w-full p-4 rounded-lg border-2 text-left ${
                      appointmentType === 'in_person' 
                        ? 'border-red-500 bg-red-50' 
                        : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <MapPin className="h-5 w-5 text-red-600" />
                      <div>
                        <p className="font-medium text-gray-800">In-Person Consultation</p>
                        <p className="text-sm text-gray-600">Visit clinic for physical examination</p>
                      </div>
                    </div>
                  </button>
                  
                  <button
                    onClick={() => setAppointmentType('telemedicine')}
                    className={`w-full p-4 rounded-lg border-2 text-left ${
                      appointmentType === 'telemedicine' 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <Video className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium text-gray-800">Video Consultation</p>
                        <p className="text-sm text-gray-600">Consult from home via video call</p>
                      </div>
                    </div>
                  </button>
                </CardContent>
              </Card>

              <Button 
                onClick={() => setStep(2)}
                className="w-full cardiac-gradient text-white"
              >
                Continue
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              {/* Date Selection */}
              <Card>
                <CardHeader>
                  <h3 className="font-semibold text-gray-800">Select Date</h3>
                </CardHeader>
                <CardContent>
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min={getMinDate()}
                    max={getMaxDate()}
                    className="w-full"
                  />
                </CardContent>
              </Card>

              {/* Clinic Selection (for in-person) */}
              {appointmentType === 'in_person' && (
                <Card>
                  <CardHeader>
                    <h3 className="font-semibold text-gray-800">Select Clinic</h3>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {clinics.map((clinic, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedClinic(clinic.name)}
                        className={`w-full p-4 rounded-lg border-2 text-left ${
                          selectedClinic === clinic.name 
                            ? 'border-red-500 bg-red-50' 
                            : 'border-gray-200'
                        }`}
                      >
                        <div className="flex items-center space-x-3">
                          <MapPin className="h-5 w-5 text-red-600" />
                          <div>
                            <p className="font-medium text-gray-800">{clinic.name}</p>
                            <p className="text-sm text-gray-600">{clinic.address}</p>
                            <p className="text-xs text-gray-500">{clinic.hours}</p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Time Selection */}
              {selectedDate && (appointmentType === 'telemedicine' || selectedClinic) && (
                <Card>
                  <CardHeader>
                    <h3 className="font-semibold text-gray-800">Select Time</h3>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-2">
                      {timeSlots.map((time) => (
                        <button
                          key={time}
                          onClick={() => setSelectedTime(time)}
                          className={`p-3 rounded-lg border text-sm ${
                            selectedTime === time
                              ? 'border-red-500 bg-red-50 text-red-700'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              <Button 
                onClick={() => setStep(3)}
                disabled={!selectedDate || !selectedTime || (appointmentType === 'in_person' && !selectedClinic)}
                className="w-full cardiac-gradient text-white"
              >
                Continue
              </Button>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <h3 className="font-semibold text-gray-800">Appointment Details</h3>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Chief Complaint *
                    </label>
                    <Input
                      placeholder="e.g., Chest pain, High blood pressure"
                      value={formData.chief_complaint}
                      onChange={(e) => setFormData({...formData, chief_complaint: e.target.value})}
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Symptoms
                    </label>
                    <Textarea
                      placeholder="Describe your symptoms in detail"
                      value={formData.symptoms}
                      onChange={(e) => setFormData({...formData, symptoms: e.target.value})}
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Additional Notes
                    </label>
                    <Textarea
                      placeholder="Any additional information for the doctor"
                      value={formData.notes}
                      onChange={(e) => setFormData({...formData, notes: e.target.value})}
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>

              <Button 
                onClick={() => setStep(4)}
                disabled={!formData.chief_complaint}
                className="w-full cardiac-gradient text-white"
              >
                Review Appointment
              </Button>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <h3 className="font-semibold text-gray-800">Appointment Summary</h3>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Doctor:</span>
                    <span className="font-medium">{doctor.full_name}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600">Date:</span>
                    <span className="font-medium">{new Date(selectedDate).toLocaleDateString()}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600">Time:</span>
                    <span className="font-medium">{selectedTime}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600">Type:</span>
                    <span className="font-medium">
                      {appointmentType === 'in_person' ? 'In-Person' : 'Video Consultation'}
                    </span>
                  </div>
                  
                  {selectedClinic && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Clinic:</span>
                      <span className="font-medium">{selectedClinic}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600">Chief Complaint:</span>
                    <span className="font-medium">{formData.chief_complaint}</span>
                  </div>
                  
                  <div className="border-t pt-4">
                    <div className="flex justify-between text-lg font-semibold">
                      <span>Total Fee:</span>
                      <span className="text-red-600">PKR {doctor.consultation_fee}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button 
                onClick={handleBookAppointment}
                disabled={isLoading}
                className="w-full cardiac-gradient text-white"
              >
                {isLoading ? 'Booking...' : 'Confirm & Pay'}
              </Button>
            </div>
          )}
        </div>
      </div>
    </MobileContainer>
  );
};

export default BookAppointmentScreen;

