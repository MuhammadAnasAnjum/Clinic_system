#!/usr/bin/env python3
"""
Seed data script for CardioConnect application
This script populates the database with initial data for Dr. Zafar Iqbal's practice
"""

import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from datetime import datetime, date, time, timedelta
from src.main import app
from src.models import (
    db, Doctor, ClinicSchedule, Patient, Appointment, 
    AppointmentSlot, AppointmentStatus, AppointmentType, PaymentStatus
)

def create_doctor():
    """Create Dr. Zafar Iqbal's profile"""
    doctor = Doctor(
        full_name="Dr. Zafar Iqbal",
        email="dr.zafar.iqbal@cardioconnect.pk",
        phone_number="+923001234567",
        qualifications="MBBS, FCPS (Cardiologist)",
        specializations="Blood pressure, heart conditions, cardiography, angioplasty",
        license_number="PMC-12345-CARDIO",
        experience_years=15,
        affiliated_institution="Punjab Institute of Cardiology, Lahore",
        bio="Dr. Zafar Iqbal is a highly experienced cardiologist with over 15 years of practice. He specializes in interventional cardiology, including angioplasty procedures, and has extensive experience in managing complex cardiac conditions. Dr. Iqbal is committed to providing comprehensive cardiac care to patients in Sahiwal and surrounding areas.",
        consultation_fee=2000.0,
        is_active=True,
        is_available_online=True
    )
    
    # Set password for admin login
    doctor.set_password("admin123")
    
    db.session.add(doctor)
    db.session.flush()  # Get the ID
    
    return doctor

def create_clinic_schedules(doctor):
    """Create clinic schedules for Dr. Zafar Iqbal"""
    schedules = [
        # Lifeline Clinic - Monday to Friday, 2 PM - 5 PM
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Lifeline Clinic",
            clinic_address="Jail Road, Sahiwal",
            day_of_week=0,  # Monday
            start_time=time(14, 0),  # 2 PM
            end_time=time(17, 0),   # 5 PM
            is_active=True
        ),
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Lifeline Clinic",
            clinic_address="Jail Road, Sahiwal",
            day_of_week=1,  # Tuesday
            start_time=time(14, 0),
            end_time=time(17, 0),
            is_active=True
        ),
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Lifeline Clinic",
            clinic_address="Jail Road, Sahiwal",
            day_of_week=2,  # Wednesday
            start_time=time(14, 0),
            end_time=time(17, 0),
            is_active=True
        ),
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Lifeline Clinic",
            clinic_address="Jail Road, Sahiwal",
            day_of_week=3,  # Thursday
            start_time=time(14, 0),
            end_time=time(17, 0),
            is_active=True
        ),
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Lifeline Clinic",
            clinic_address="Jail Road, Sahiwal",
            day_of_week=4,  # Friday
            start_time=time(14, 0),
            end_time=time(17, 0),
            is_active=True
        ),
        
        # Care Hospital - Monday to Saturday, 5 PM - 9 PM
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Care Hospital",
            clinic_address="Bhindari Chowk, Sahiwal",
            day_of_week=0,  # Monday
            start_time=time(17, 0),  # 5 PM
            end_time=time(21, 0),   # 9 PM
            is_active=True
        ),
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Care Hospital",
            clinic_address="Bhindari Chowk, Sahiwal",
            day_of_week=1,  # Tuesday
            start_time=time(17, 0),
            end_time=time(21, 0),
            is_active=True
        ),
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Care Hospital",
            clinic_address="Bhindari Chowk, Sahiwal",
            day_of_week=2,  # Wednesday
            start_time=time(17, 0),
            end_time=time(21, 0),
            is_active=True
        ),
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Care Hospital",
            clinic_address="Bhindari Chowk, Sahiwal",
            day_of_week=3,  # Thursday
            start_time=time(17, 0),
            end_time=time(21, 0),
            is_active=True
        ),
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Care Hospital",
            clinic_address="Bhindari Chowk, Sahiwal",
            day_of_week=4,  # Friday
            start_time=time(17, 0),
            end_time=time(21, 0),
            is_active=True
        ),
        ClinicSchedule(
            doctor_id=doctor.id,
            clinic_name="Care Hospital",
            clinic_address="Bhindari Chowk, Sahiwal",
            day_of_week=5,  # Saturday
            start_time=time(17, 0),
            end_time=time(21, 0),
            is_active=True
        )
    ]
    
    for schedule in schedules:
        db.session.add(schedule)
    
    return schedules

def create_sample_patients():
    """Create sample patients for testing"""
    patients = [
        {
            'full_name': 'Ahmed Khan',
            'phone_number': '03001234567',
            'email': 'ahmed.khan@email.com',
            'date_of_birth': date(1980, 5, 15),
            'blood_group': 'B+',
            'medical_history': 'Hypertension, family history of heart disease',
            'current_medications': 'Amlodipine 5mg daily'
        },
        {
            'full_name': 'Fatima Ali',
            'phone_number': '03009876543',
            'email': 'fatima.ali@email.com',
            'date_of_birth': date(1975, 8, 22),
            'blood_group': 'A+',
            'allergies': 'Penicillin',
            'medical_history': 'Diabetes Type 2, high cholesterol',
            'current_medications': 'Metformin 500mg twice daily, Atorvastatin 20mg'
        },
        {
            'full_name': 'Muhammad Hassan',
            'phone_number': '03007654321',
            'email': 'hassan.muhammad@email.com',
            'date_of_birth': date(1990, 12, 10),
            'blood_group': 'O+',
            'emergency_contact_name': 'Sarah Hassan',
            'emergency_contact_phone': '03001111111'
        },
        {
            'full_name': 'Aisha Malik',
            'phone_number': '03005555555',
            'email': 'aisha.malik@email.com',
            'date_of_birth': date(1985, 3, 8),
            'blood_group': 'AB+',
            'medical_history': 'Previous heart palpitations',
            'allergies': 'Aspirin'
        }
    ]
    
    created_patients = []
    for patient_data in patients:
        patient = Patient(**patient_data)
        patient.set_password('patient123')  # Default password for testing
        db.session.add(patient)
        created_patients.append(patient)
    
    db.session.flush()  # Get IDs
    return created_patients

def generate_appointment_slots(doctor, schedules):
    """Generate appointment slots for the next 30 days"""
    start_date = date.today()
    end_date = start_date + timedelta(days=30)
    slot_duration = 30  # minutes
    
    current_date = start_date
    slots_created = 0
    
    while current_date <= end_date:
        day_of_week = current_date.weekday()  # 0=Monday, 6=Sunday
        
        # Find schedules for this day
        day_schedules = [s for s in schedules if s.day_of_week == day_of_week]
        
        for schedule in day_schedules:
            # Generate slots for this schedule
            current_time = datetime.combine(current_date, schedule.start_time)
            end_time = datetime.combine(current_date, schedule.end_time)
            
            while current_time + timedelta(minutes=slot_duration) <= end_time:
                slot = AppointmentSlot(
                    doctor_id=doctor.id,
                    slot_date=current_date,
                    slot_time=current_time.time(),
                    duration_minutes=slot_duration,
                    clinic_name=schedule.clinic_name,
                    clinic_address=schedule.clinic_address,
                    allows_in_person=True,
                    allows_telemedicine=True,
                    is_available=True,
                    is_blocked=False
                )
                db.session.add(slot)
                slots_created += 1
                
                current_time += timedelta(minutes=slot_duration)
        
        current_date += timedelta(days=1)
    
    print(f"Generated {slots_created} appointment slots")
    return slots_created

def create_sample_appointments(doctor, patients):
    """Create some sample appointments"""
    # Create a few sample appointments
    tomorrow = date.today() + timedelta(days=1)
    day_after = date.today() + timedelta(days=2)
    
    appointments = [
        Appointment(
            patient_id=patients[0].id,
            doctor_id=doctor.id,
            appointment_date=tomorrow,
            appointment_time=time(14, 30),
            appointment_type=AppointmentType.IN_PERSON,
            clinic_name="Lifeline Clinic",
            clinic_address="Jail Road, Sahiwal",
            chief_complaint="Chest pain and shortness of breath",
            symptoms="Experiencing chest discomfort during physical activity",
            consultation_fee=doctor.consultation_fee,
            status=AppointmentStatus.SCHEDULED,
            payment_status=PaymentStatus.PENDING
        ),
        Appointment(
            patient_id=patients[1].id,
            doctor_id=doctor.id,
            appointment_date=day_after,
            appointment_time=time(18, 0),
            appointment_type=AppointmentType.TELEMEDICINE,
            chief_complaint="Follow-up for blood pressure monitoring",
            symptoms="Regular check-up for hypertension management",
            consultation_fee=doctor.consultation_fee,
            status=AppointmentStatus.CONFIRMED,
            payment_status=PaymentStatus.PAID,
            payment_method="jazzcash",
            payment_transaction_id="TXN_20240717_ABC123",
            payment_date=datetime.utcnow(),
            video_call_room_id="room_abc123",
            video_call_link="/video-call/room_abc123"
        )
    ]
    
    for appointment in appointments:
        db.session.add(appointment)
        
        # Mark corresponding slots as unavailable
        slot = AppointmentSlot.query.filter(
            AppointmentSlot.doctor_id == doctor.id,
            AppointmentSlot.slot_date == appointment.appointment_date,
            AppointmentSlot.slot_time == appointment.appointment_time
        ).first()
        
        if slot:
            slot.is_available = False
    
    return appointments

def main():
    """Main function to seed the database"""
    with app.app_context():
        print("Starting database seeding...")
        
        # Check if doctor already exists
        existing_doctor = Doctor.query.filter_by(email="dr.zafar.iqbal@cardioconnect.pk").first()
        if existing_doctor:
            print("Doctor already exists. Skipping seeding.")
            return
        
        try:
            # Create doctor
            print("Creating doctor profile...")
            doctor = create_doctor()
            
            # Create clinic schedules
            print("Creating clinic schedules...")
            schedules = create_clinic_schedules(doctor)
            
            # Create sample patients
            print("Creating sample patients...")
            patients = create_sample_patients()
            
            # Commit to get IDs
            db.session.commit()
            
            # Generate appointment slots
            print("Generating appointment slots...")
            generate_appointment_slots(doctor, schedules)
            
            # Create sample appointments
            print("Creating sample appointments...")
            create_sample_appointments(doctor, patients)
            
            # Final commit
            db.session.commit()
            
            print("Database seeding completed successfully!")
            print(f"Doctor created: {doctor.full_name}")
            print(f"Clinic schedules created: {len(schedules)}")
            print(f"Sample patients created: {len(patients)}")
            print("\nLogin credentials:")
            print("Doctor (Admin): dr.zafar.iqbal@cardioconnect.pk / admin123")
            print("Sample Patient: 03001234567 / patient123")
            
        except Exception as e:
            db.session.rollback()
            print(f"Error during seeding: {str(e)}")
            raise

if __name__ == '__main__':
    main()

