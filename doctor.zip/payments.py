from flask import Blueprint, request, jsonify, session
from datetime import datetime
from src.models.base import db, Appointment, PaymentStatus
import uuid
import hashlib
import hmac

payments_bp = Blueprint('payments', __name__)

def require_auth(user_type=None):
    """Decorator to require authentication"""
    def decorator(f):
        def wrapper(*args, **kwargs):
            if 'user_id' not in session or 'user_type' not in session:
                return jsonify({'error': 'Authentication required'}), 401
            
            if user_type and session['user_type'] != user_type:
                return jsonify({'error': 'Insufficient permissions'}), 403
            
            return f(*args, **kwargs)
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator

def generate_transaction_id():
    """Generate a unique transaction ID"""
    return f"TXN_{datetime.now().strftime('%Y%m%d%H%M%S')}_{str(uuid.uuid4())[:8].upper()}"

def simulate_payment_processing(payment_method, amount, payment_details):
    """Simulate payment processing for different payment methods"""
    # This is a simulation - in real implementation, you would integrate with actual payment gateways
    
    if payment_method == 'credit_card':
        # Simulate credit card processing
        card_number = payment_details.get('card_number', '')
        if len(card_number) < 16:
            return False, "Invalid card number"
        
        # Simulate 95% success rate
        import random
        return random.random() < 0.95, "Payment processed successfully" if random.random() < 0.95 else "Card declined"
    
    elif payment_method == 'jazzcash':
        # Simulate JazzCash processing
        phone_number = payment_details.get('phone_number', '')
        if not phone_number.startswith('03'):
            return False, "Invalid JazzCash phone number"
        
        # Simulate 90% success rate
        import random
        return random.random() < 0.90, "JazzCash payment successful" if random.random() < 0.90 else "JazzCash payment failed"
    
    elif payment_method == 'easypaisa':
        # Simulate EasyPaisa processing
        phone_number = payment_details.get('phone_number', '')
        if not phone_number.startswith('03'):
            return False, "Invalid EasyPaisa phone number"
        
        # Simulate 90% success rate
        import random
        return random.random() < 0.90, "EasyPaisa payment successful" if random.random() < 0.90 else "EasyPaisa payment failed"
    
    elif payment_method == 'bank_transfer':
        # Simulate bank transfer processing
        account_number = payment_details.get('account_number', '')
        if len(account_number) < 10:
            return False, "Invalid account number"
        
        # Simulate 85% success rate (bank transfers can be slower/more prone to issues)
        import random
        return random.random() < 0.85, "Bank transfer initiated" if random.random() < 0.85 else "Bank transfer failed"
    
    else:
        return False, "Unsupported payment method"

@payments_bp.route('/methods', methods=['GET'])
def get_payment_methods():
    """Get available payment methods"""
    try:
        payment_methods = [
            {
                'id': 'credit_card',
                'name': 'Credit/Debit Card',
                'description': 'Pay with Visa, MasterCard, or local bank cards',
                'icon': 'credit-card',
                'processing_fee': 2.5,  # percentage
                'is_available': True
            },
            {
                'id': 'jazzcash',
                'name': 'JazzCash',
                'description': 'Pay with your JazzCash mobile wallet',
                'icon': 'jazzcash',
                'processing_fee': 1.0,  # percentage
                'is_available': True
            },
            {
                'id': 'easypaisa',
                'name': 'EasyPaisa',
                'description': 'Pay with your EasyPaisa mobile wallet',
                'icon': 'easypaisa',
                'processing_fee': 1.0,  # percentage
                'is_available': True
            },
            {
                'id': 'bank_transfer',
                'name': 'Bank Transfer',
                'description': 'Direct bank transfer (may take 1-2 business days)',
                'icon': 'bank',
                'processing_fee': 0.0,  # percentage
                'is_available': True
            }
        ]
        
        return jsonify({
            'payment_methods': payment_methods
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@payments_bp.route('/appointment/<int:appointment_id>/pay', methods=['POST'])
@require_auth('patient')
def process_appointment_payment():
    """Process payment for an appointment"""
    try:
        patient_id = session['user_id']
        appointment = Appointment.query.get(appointment_id)
        
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        if appointment.patient_id != patient_id:
            return jsonify({'error': 'Access denied'}), 403
        
        if appointment.payment_status == PaymentStatus.PAID:
            return jsonify({'error': 'Payment already completed'}), 400
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['payment_method']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        payment_method = data['payment_method']
        payment_details = data.get('payment_details', {})
        
        # Validate payment method
        valid_methods = ['credit_card', 'jazzcash', 'easypaisa', 'bank_transfer']
        if payment_method not in valid_methods:
            return jsonify({'error': 'Invalid payment method'}), 400
        
        # Generate transaction ID
        transaction_id = generate_transaction_id()
        
        # Process payment (simulation)
        success, message = simulate_payment_processing(payment_method, appointment.consultation_fee, payment_details)
        
        if success:
            # Update appointment payment status
            appointment.payment_status = PaymentStatus.PAID
            appointment.payment_method = payment_method
            appointment.payment_transaction_id = transaction_id
            appointment.payment_date = datetime.utcnow()
            
            db.session.commit()
            
            return jsonify({
                'message': 'Payment processed successfully',
                'transaction_id': transaction_id,
                'amount': appointment.consultation_fee,
                'payment_method': payment_method,
                'appointment': appointment.to_dict_with_details()
            }), 200
        
        else:
            # Payment failed
            appointment.payment_status = PaymentStatus.FAILED
            appointment.payment_method = payment_method
            appointment.payment_transaction_id = transaction_id
            
            db.session.commit()
            
            return jsonify({
                'error': 'Payment failed',
                'message': message,
                'transaction_id': transaction_id
            }), 400
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@payments_bp.route('/appointment/<int:appointment_id>/payment-status', methods=['GET'])
@require_auth()
def get_appointment_payment_status():
    """Get payment status for an appointment"""
    try:
        user_id = session['user_id']
        user_type = session['user_type']
        
        appointment = Appointment.query.get(appointment_id)
        
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        # Check permissions
        if user_type == 'patient' and appointment.patient_id != user_id:
            return jsonify({'error': 'Access denied'}), 403
        elif user_type == 'doctor' and appointment.doctor_id != user_id:
            return jsonify({'error': 'Access denied'}), 403
        
        return jsonify({
            'appointment_id': appointment.id,
            'payment_status': appointment.payment_status.value,
            'payment_method': appointment.payment_method,
            'payment_transaction_id': appointment.payment_transaction_id,
            'payment_date': appointment.payment_date.isoformat() if appointment.payment_date else None,
            'consultation_fee': appointment.consultation_fee
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@payments_bp.route('/patient/payment-history', methods=['GET'])
@require_auth('patient')
def get_patient_payment_history():
    """Get payment history for current patient"""
    try:
        patient_id = session['user_id']
        
        appointments = Appointment.query.filter(
            Appointment.patient_id == patient_id,
            Appointment.payment_status.in_([PaymentStatus.PAID, PaymentStatus.FAILED])
        ).order_by(Appointment.payment_date.desc()).all()
        
        payment_history = []
        for appointment in appointments:
            payment_history.append({
                'appointment_id': appointment.id,
                'appointment_date': appointment.appointment_date.isoformat(),
                'appointment_time': appointment.appointment_time.strftime('%H:%M'),
                'doctor_name': appointment.doctor.full_name if appointment.doctor else None,
                'consultation_fee': appointment.consultation_fee,
                'payment_status': appointment.payment_status.value,
                'payment_method': appointment.payment_method,
                'payment_transaction_id': appointment.payment_transaction_id,
                'payment_date': appointment.payment_date.isoformat() if appointment.payment_date else None
            })
        
        return jsonify({
            'payment_history': payment_history
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@payments_bp.route('/doctor/revenue', methods=['GET'])
@require_auth('doctor')
def get_doctor_revenue():
    """Get revenue statistics for doctor"""
    try:
        doctor_id = session['user_id']
        
        # Get query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        query = Appointment.query.filter(
            Appointment.doctor_id == doctor_id,
            Appointment.payment_status == PaymentStatus.PAID
        )
        
        if start_date:
            try:
                start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
                query = query.filter(Appointment.appointment_date >= start_date)
            except ValueError:
                return jsonify({'error': 'Invalid start_date format. Use YYYY-MM-DD'}), 400
        
        if end_date:
            try:
                end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
                query = query.filter(Appointment.appointment_date <= end_date)
            except ValueError:
                return jsonify({'error': 'Invalid end_date format. Use YYYY-MM-DD'}), 400
        
        appointments = query.order_by(Appointment.payment_date.desc()).all()
        
        # Calculate statistics
        total_revenue = sum(appointment.consultation_fee for appointment in appointments)
        total_appointments = len(appointments)
        
        # Group by payment method
        payment_methods = {}
        for appointment in appointments:
            method = appointment.payment_method
            if method not in payment_methods:
                payment_methods[method] = {'count': 0, 'revenue': 0}
            payment_methods[method]['count'] += 1
            payment_methods[method]['revenue'] += appointment.consultation_fee
        
        # Recent transactions
        recent_transactions = []
        for appointment in appointments[:10]:  # Last 10 transactions
            recent_transactions.append({
                'appointment_id': appointment.id,
                'patient_name': appointment.patient.full_name if appointment.patient else None,
                'appointment_date': appointment.appointment_date.isoformat(),
                'consultation_fee': appointment.consultation_fee,
                'payment_method': appointment.payment_method,
                'payment_date': appointment.payment_date.isoformat() if appointment.payment_date else None
            })
        
        return jsonify({
            'revenue_summary': {
                'total_revenue': total_revenue,
                'total_appointments': total_appointments,
                'average_fee': total_revenue / total_appointments if total_appointments > 0 else 0
            },
            'payment_methods': payment_methods,
            'recent_transactions': recent_transactions
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@payments_bp.route('/webhook/payment-confirmation', methods=['POST'])
def payment_webhook():
    """Webhook endpoint for payment gateway confirmations"""
    try:
        # This would be used for real payment gateway webhooks
        # For now, it's a placeholder for future implementation
        
        data = request.get_json()
        
        # Validate webhook signature (implementation depends on payment gateway)
        # signature = request.headers.get('X-Signature')
        # if not validate_webhook_signature(data, signature):
        #     return jsonify({'error': 'Invalid signature'}), 401
        
        transaction_id = data.get('transaction_id')
        status = data.get('status')  # 'success', 'failed', 'pending'
        
        if not transaction_id:
            return jsonify({'error': 'Transaction ID required'}), 400
        
        # Find appointment by transaction ID
        appointment = Appointment.query.filter(
            Appointment.payment_transaction_id == transaction_id
        ).first()
        
        if not appointment:
            return jsonify({'error': 'Transaction not found'}), 404
        
        # Update payment status based on webhook
        if status == 'success':
            appointment.payment_status = PaymentStatus.PAID
            appointment.payment_date = datetime.utcnow()
        elif status == 'failed':
            appointment.payment_status = PaymentStatus.FAILED
        # For 'pending', keep current status
        
        db.session.commit()
        
        return jsonify({
            'message': 'Webhook processed successfully',
            'transaction_id': transaction_id,
            'status': status
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

