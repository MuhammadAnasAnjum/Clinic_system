import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginScreen from './components/LoginScreen';
import RegisterScreen from './components/RegisterScreen';
import DashboardScreen from './components/DashboardScreen';
import BookAppointmentScreen from './components/BookAppointmentScreen';
import MobileContainer from './components/MobileContainer';
import { Heart } from 'lucide-react';
import './App.css';

// Loading component
const LoadingScreen = () => (
  <MobileContainer>
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
      <div className="text-center">
        <Heart className="h-12 w-12 text-red-600 mx-auto mb-4 heart-pulse" />
        <h2 className="text-xl font-semibold text-gray-800 mb-2">CardioConnect</h2>
        <p className="text-gray-600">Loading...</p>
      </div>
    </div>
  </MobileContainer>
);

// Doctor Login Screen (simplified)
const DoctorLoginScreen = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    const result = await login({ email, password }, 'doctor');
    
    if (result.success) {
      onNavigate('doctor-dashboard');
    } else {
      setError(result.error || 'Login failed');
    }
    
    setIsLoading(false);
  };

  return (
    <MobileContainer>
      <div className="flex flex-col min-h-screen bg-gradient-to-br from-blue-50 to-red-50">
        <div className="flex items-center p-4">
          <button 
            onClick={() => onNavigate('login')}
            className="p-2 rounded-full hover:bg-gray-100"
          >
            ←
          </button>
          <h1 className="flex-1 text-center text-lg font-semibold text-gray-800 pr-9">
            Doctor Login
          </h1>
        </div>

        <div className="flex-1 flex items-center justify-center px-6">
          <div className="w-full max-w-sm bg-white rounded-lg shadow-lg p-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-blue-600" />
              </div>
              <h2 className="text-xl font-semibold text-gray-800">Admin Access</h2>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="dr.zafar.iqbal@cardioconnect.pk"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter password"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full medical-gradient text-white p-3 rounded-lg font-medium"
              >
                {isLoading ? 'Signing In...' : 'Sign In'}
              </button>
            </form>

            <div className="mt-6 p-3 bg-blue-50 rounded-lg">
              <p className="text-xs text-blue-700">
                Demo: dr.zafar.iqbal@cardioconnect.pk / admin123
              </p>
            </div>
          </div>
        </div>
      </div>
    </MobileContainer>
  );
};

// Simple Doctor Dashboard
const DoctorDashboardScreen = ({ onNavigate }) => {
  const { user, logout } = useAuth();

  return (
    <MobileContainer>
      <div className="flex flex-col min-h-screen bg-gray-50">
        <div className="bg-white shadow-sm p-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-lg font-semibold text-gray-800">Admin Dashboard</h1>
              <p className="text-sm text-gray-600">{user?.full_name}</p>
            </div>
            <button 
              onClick={logout}
              className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm"
            >
              Logout
            </button>
          </div>
        </div>

        <div className="flex-1 p-4">
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-white p-4 rounded-lg shadow">
              <h3 className="text-2xl font-bold text-gray-800">8</h3>
              <p className="text-sm text-gray-600">Today's Appointments</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow">
              <h3 className="text-2xl font-bold text-gray-800">3</h3>
              <p className="text-sm text-gray-600">Pending Consultations</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow">
              <h3 className="text-2xl font-bold text-gray-800">245</h3>
              <p className="text-sm text-gray-600">Total Patients</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow">
              <h3 className="text-2xl font-bold text-gray-800">125K</h3>
              <p className="text-sm text-gray-600">Revenue (PKR)</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <h3 className="font-semibold text-gray-800 mb-4">Quick Actions</h3>
            <div className="space-y-2">
              <button className="w-full p-3 text-left bg-blue-50 rounded-lg">
                View Today's Schedule
              </button>
              <button className="w-full p-3 text-left bg-green-50 rounded-lg">
                Manage Availability
              </button>
              <button className="w-full p-3 text-left bg-purple-50 rounded-lg">
                Patient Records
              </button>
              <button className="w-full p-3 text-left bg-orange-50 rounded-lg">
                Reports & Analytics
              </button>
            </div>
          </div>
        </div>
      </div>
    </MobileContainer>
  );
};

// Main App Router Component
const AppRouter = () => {
  const { user, userType, loading } = useAuth();
  const [currentScreen, setCurrentScreen] = useState('login');
  const [screenData, setScreenData] = useState({});

  const navigate = (screen, data = {}) => {
    setCurrentScreen(screen);
    setScreenData(data);
  };

  if (loading) {
    return <LoadingScreen />;
  }

  // If user is authenticated, show appropriate dashboard
  if (user) {
    if (userType === 'doctor') {
      if (currentScreen === 'login' || currentScreen === 'doctor-login') {
        setCurrentScreen('doctor-dashboard');
      }
      
      switch (currentScreen) {
        case 'doctor-dashboard':
          return <DoctorDashboardScreen onNavigate={navigate} />;
        default:
          return <DoctorDashboardScreen onNavigate={navigate} />;
      }
    } else {
      // Patient user
      if (currentScreen === 'login' || currentScreen === 'register') {
        setCurrentScreen('dashboard');
      }
      
      switch (currentScreen) {
        case 'dashboard':
          return <DashboardScreen onNavigate={navigate} />;
        case 'book-appointment':
          return <BookAppointmentScreen onNavigate={navigate} />;
        case 'appointments':
        case 'medical-records':
        case 'prescriptions':
        case 'profile':
          return (
            <MobileContainer>
              <div className="flex items-center justify-center min-h-screen">
                <div className="text-center">
                  <Heart className="h-8 w-8 text-red-600 mx-auto mb-4" />
                  <h2 className="text-lg font-semibold text-gray-800 mb-2">
                    {currentScreen.charAt(0).toUpperCase() + currentScreen.slice(1).replace('-', ' ')}
                  </h2>
                  <p className="text-gray-600 mb-4">This feature is coming soon!</p>
                  <button 
                    onClick={() => navigate('dashboard')}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg"
                  >
                    Back to Dashboard
                  </button>
                </div>
              </div>
            </MobileContainer>
          );
        default:
          return <DashboardScreen onNavigate={navigate} />;
      }
    }
  }

  // Not authenticated - show auth screens
  switch (currentScreen) {
    case 'register':
      return <RegisterScreen onNavigate={navigate} />;
    case 'doctor-login':
      return <DoctorLoginScreen onNavigate={navigate} />;
    case 'forgot-password':
      return (
        <MobileContainer>
          <div className="flex items-center justify-center min-h-screen">
            <div className="text-center">
              <Heart className="h-8 w-8 text-red-600 mx-auto mb-4" />
              <h2 className="text-lg font-semibold text-gray-800 mb-2">Forgot Password</h2>
              <p className="text-gray-600 mb-4">This feature is coming soon!</p>
              <button 
                onClick={() => navigate('login')}
                className="px-4 py-2 bg-red-600 text-white rounded-lg"
              >
                Back to Login
              </button>
            </div>
          </div>
        </MobileContainer>
      );
    default:
      return <LoginScreen onNavigate={navigate} />;
  }
};

// Main App Component
function App() {
  return (
    <AuthProvider>
      <div className="App">
        <AppRouter />
      </div>
    </AuthProvider>
  );
}

export default App;

