from flask import Blueprint, request, jsonify, session
from datetime import datetime, date
from src.models.base import db, MedicalRecord, Prescription, Patient, Doctor, RecordType
import os
from werkzeug.utils import secure_filename

medical_records_bp = Blueprint('medical_records', __name__)

def require_auth(user_type=None):
    """Decorator to require authentication"""
    def decorator(f):
        def wrapper(*args, **kwargs):
            if 'user_id' not in session or 'user_type' not in session:
                return jsonify({'error': 'Authentication required'}), 401
            
            if user_type and session['user_type'] != user_type:
                return jsonify({'error': 'Insufficient permissions'}), 403
            
            return f(*args, **kwargs)
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator

@medical_records_bp.route('/patient/<int:patient_id>', methods=['GET'])
@require_auth()
def get_patient_medical_records():
    """Get medical records for a patient"""
    try:
        user_id = session['user_id']
        user_type = session['user_type']
        
        # Check permissions
        if user_type == 'patient' and patient_id != user_id:
            return jsonify({'error': 'Access denied'}), 403
        elif user_type == 'doctor':
            # Doctor can access records they created or for their patients
            pass
        
        record_type = request.args.get('type')
        
        query = MedicalRecord.query.filter(MedicalRecord.patient_id == patient_id)
        
        # Filter by record type if specified
        if record_type:
            try:
                record_type_enum = RecordType(record_type)
                query = query.filter(MedicalRecord.record_type == record_type_enum)
            except ValueError:
                return jsonify({'error': 'Invalid record type'}), 400
        
        # If patient is requesting, only show records shared with them
        if user_type == 'patient':
            query = query.filter(MedicalRecord.is_shared_with_patient == True)
        
        records = query.order_by(MedicalRecord.record_date.desc()).all()
        
        return jsonify({
            'medical_records': [record.to_dict_with_details() for record in records]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@medical_records_bp.route('/my-records', methods=['GET'])
@require_auth('patient')
def get_my_medical_records():
    """Get current patient's medical records"""
    try:
        patient_id = session['user_id']
        record_type = request.args.get('type')
        
        query = MedicalRecord.query.filter(
            MedicalRecord.patient_id == patient_id,
            MedicalRecord.is_shared_with_patient == True
        )
        
        # Filter by record type if specified
        if record_type:
            try:
                record_type_enum = RecordType(record_type)
                query = query.filter(MedicalRecord.record_type == record_type_enum)
            except ValueError:
                return jsonify({'error': 'Invalid record type'}), 400
        
        records = query.order_by(MedicalRecord.record_date.desc()).all()
        
        return jsonify({
            'medical_records': [record.to_dict_with_details() for record in records]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@medical_records_bp.route('/', methods=['POST'])
@require_auth('doctor')
def create_medical_record():
    """Create a new medical record"""
    try:
        doctor_id = session['user_id']
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['patient_id', 'record_type', 'title', 'record_date']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate patient exists
        patient = Patient.query.get(data['patient_id'])
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404
        
        # Validate record type
        try:
            record_type = RecordType(data['record_type'])
        except ValueError:
            return jsonify({'error': 'Invalid record type'}), 400
        
        # Parse record date
        try:
            record_date = datetime.strptime(data['record_date'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
        
        # Create medical record
        medical_record = MedicalRecord(
            patient_id=data['patient_id'],
            doctor_id=doctor_id,
            appointment_id=data.get('appointment_id'),
            record_type=record_type,
            title=data['title'],
            description=data.get('description'),
            record_date=record_date,
            chief_complaint=data.get('chief_complaint'),
            history_of_present_illness=data.get('history_of_present_illness'),
            physical_examination=data.get('physical_examination'),
            assessment=data.get('assessment'),
            plan=data.get('plan'),
            blood_pressure_systolic=data.get('blood_pressure_systolic'),
            blood_pressure_diastolic=data.get('blood_pressure_diastolic'),
            heart_rate=data.get('heart_rate'),
            temperature=data.get('temperature'),
            weight=data.get('weight'),
            height=data.get('height'),
            is_confidential=data.get('is_confidential', False),
            is_shared_with_patient=data.get('is_shared_with_patient', True)
        )
        
        db.session.add(medical_record)
        db.session.commit()
        
        return jsonify({
            'message': 'Medical record created successfully',
            'medical_record': medical_record.to_dict_with_details()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@medical_records_bp.route('/<int:record_id>', methods=['GET'])
@require_auth()
def get_medical_record():
    """Get a specific medical record"""
    try:
        record = MedicalRecord.query.get(record_id)
        if not record:
            return jsonify({'error': 'Medical record not found'}), 404
        
        user_id = session['user_id']
        user_type = session['user_type']
        
        # Check permissions
        if user_type == 'patient':
            if record.patient_id != user_id or not record.is_shared_with_patient:
                return jsonify({'error': 'Access denied'}), 403
        elif user_type == 'doctor':
            if record.doctor_id != user_id:
                return jsonify({'error': 'Access denied'}), 403
        
        return jsonify({
            'medical_record': record.to_dict_with_details()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@medical_records_bp.route('/<int:record_id>', methods=['PUT'])
@require_auth('doctor')
def update_medical_record():
    """Update a medical record"""
    try:
        record = MedicalRecord.query.get(record_id)
        if not record:
            return jsonify({'error': 'Medical record not found'}), 404
        
        doctor_id = session['user_id']
        if record.doctor_id != doctor_id:
            return jsonify({'error': 'Access denied'}), 403
        
        data = request.get_json()
        
        # Update allowed fields
        updatable_fields = [
            'title', 'description', 'chief_complaint', 'history_of_present_illness',
            'physical_examination', 'assessment', 'plan', 'blood_pressure_systolic',
            'blood_pressure_diastolic', 'heart_rate', 'temperature', 'weight', 'height',
            'is_confidential', 'is_shared_with_patient'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(record, field, data[field])
        
        record.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Medical record updated successfully',
            'medical_record': record.to_dict_with_details()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@medical_records_bp.route('/<int:record_id>/prescriptions', methods=['GET'])
@require_auth()
def get_record_prescriptions():
    """Get prescriptions for a medical record"""
    try:
        record = MedicalRecord.query.get(record_id)
        if not record:
            return jsonify({'error': 'Medical record not found'}), 404
        
        user_id = session['user_id']
        user_type = session['user_type']
        
        # Check permissions
        if user_type == 'patient':
            if record.patient_id != user_id or not record.is_shared_with_patient:
                return jsonify({'error': 'Access denied'}), 403
        elif user_type == 'doctor':
            if record.doctor_id != user_id:
                return jsonify({'error': 'Access denied'}), 403
        
        prescriptions = Prescription.query.filter(
            Prescription.medical_record_id == record_id
        ).order_by(Prescription.prescribed_date.desc()).all()
        
        return jsonify({
            'prescriptions': [prescription.to_dict() for prescription in prescriptions]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@medical_records_bp.route('/<int:record_id>/prescriptions', methods=['POST'])
@require_auth('doctor')
def add_prescription():
    """Add a prescription to a medical record"""
    try:
        record = MedicalRecord.query.get(record_id)
        if not record:
            return jsonify({'error': 'Medical record not found'}), 404
        
        doctor_id = session['user_id']
        if record.doctor_id != doctor_id:
            return jsonify({'error': 'Access denied'}), 403
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['medication_name', 'dosage', 'frequency', 'duration']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Parse dates
        prescribed_date = date.today()
        start_date = None
        end_date = None
        
        if data.get('start_date'):
            try:
                start_date = datetime.strptime(data['start_date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'Invalid start_date format. Use YYYY-MM-DD'}), 400
        
        if data.get('end_date'):
            try:
                end_date = datetime.strptime(data['end_date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'Invalid end_date format. Use YYYY-MM-DD'}), 400
        
        # Create prescription
        prescription = Prescription(
            medical_record_id=record_id,
            patient_id=record.patient_id,
            doctor_id=doctor_id,
            medication_name=data['medication_name'],
            dosage=data['dosage'],
            frequency=data['frequency'],
            duration=data['duration'],
            instructions=data.get('instructions'),
            prescribed_date=prescribed_date,
            start_date=start_date,
            end_date=end_date
        )
        
        db.session.add(prescription)
        db.session.commit()
        
        return jsonify({
            'message': 'Prescription added successfully',
            'prescription': prescription.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@medical_records_bp.route('/prescriptions/<int:prescription_id>', methods=['PUT'])
@require_auth('doctor')
def update_prescription():
    """Update a prescription"""
    try:
        prescription = Prescription.query.get(prescription_id)
        if not prescription:
            return jsonify({'error': 'Prescription not found'}), 404
        
        doctor_id = session['user_id']
        if prescription.doctor_id != doctor_id:
            return jsonify({'error': 'Access denied'}), 403
        
        data = request.get_json()
        
        # Update allowed fields
        updatable_fields = [
            'medication_name', 'dosage', 'frequency', 'duration', 
            'instructions', 'is_active', 'is_completed'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(prescription, field, data[field])
        
        # Handle date updates
        if 'start_date' in data:
            if data['start_date']:
                try:
                    prescription.start_date = datetime.strptime(data['start_date'], '%Y-%m-%d').date()
                except ValueError:
                    return jsonify({'error': 'Invalid start_date format. Use YYYY-MM-DD'}), 400
            else:
                prescription.start_date = None
        
        if 'end_date' in data:
            if data['end_date']:
                try:
                    prescription.end_date = datetime.strptime(data['end_date'], '%Y-%m-%d').date()
                except ValueError:
                    return jsonify({'error': 'Invalid end_date format. Use YYYY-MM-DD'}), 400
            else:
                prescription.end_date = None
        
        db.session.commit()
        
        return jsonify({
            'message': 'Prescription updated successfully',
            'prescription': prescription.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@medical_records_bp.route('/patient/<int:patient_id>/prescriptions', methods=['GET'])
@require_auth()
def get_patient_prescriptions():
    """Get all prescriptions for a patient"""
    try:
        user_id = session['user_id']
        user_type = session['user_type']
        
        # Check permissions
        if user_type == 'patient' and patient_id != user_id:
            return jsonify({'error': 'Access denied'}), 403
        
        is_active = request.args.get('active')
        
        query = Prescription.query.filter(Prescription.patient_id == patient_id)
        
        if is_active is not None:
            query = query.filter(Prescription.is_active == (is_active.lower() == 'true'))
        
        prescriptions = query.order_by(Prescription.prescribed_date.desc()).all()
        
        return jsonify({
            'prescriptions': [prescription.to_dict() for prescription in prescriptions]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

