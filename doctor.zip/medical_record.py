from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from enum import Enum

db = SQLAlchemy()

class RecordType(Enum):
    CONSULTATION_NOTE = "consultation_note"
    PRESCRIPTION = "prescription"
    LAB_RESULT = "lab_result"
    IMAGING_REPORT = "imaging_report"
    ECG_REPORT = "ecg_report"
    ECHO_REPORT = "echo_report"
    ANGIOGRAPHY = "angiography"
    DISCHARGE_SUMMARY = "discharge_summary"
    FOLLOW_UP_NOTE = "follow_up_note"

class MedicalRecord(db.Model):
    __tablename__ = 'medical_records'
    
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=False)
    appointment_id = db.Column(db.Integer, db.ForeignKey('appointments.id'), nullable=True)
    
    # Record details
    record_type = db.Column(db.Enum(RecordType), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    record_date = db.Column(db.Date, nullable=False)
    
    # Clinical information
    chief_complaint = db.Column(db.Text, nullable=True)
    history_of_present_illness = db.Column(db.Text, nullable=True)
    physical_examination = db.Column(db.Text, nullable=True)
    assessment = db.Column(db.Text, nullable=True)
    plan = db.Column(db.Text, nullable=True)
    
    # Vital signs
    blood_pressure_systolic = db.Column(db.Integer, nullable=True)
    blood_pressure_diastolic = db.Column(db.Integer, nullable=True)
    heart_rate = db.Column(db.Integer, nullable=True)
    temperature = db.Column(db.Float, nullable=True)
    weight = db.Column(db.Float, nullable=True)
    height = db.Column(db.Float, nullable=True)
    
    # File attachments
    file_url = db.Column(db.String(500), nullable=True)
    file_name = db.Column(db.String(200), nullable=True)
    file_size = db.Column(db.Integer, nullable=True)
    file_type = db.Column(db.String(50), nullable=True)
    
    # Status and tracking
    is_confidential = db.Column(db.Boolean, default=False)
    is_shared_with_patient = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships - using string references to avoid circular imports
    prescriptions = db.relationship('Prescription', backref='medical_record', lazy=True)
    
    def to_dict(self):
        """Convert medical record to dictionary"""
        return {
            'id': self.id,
            'patient_id': self.patient_id,
            'doctor_id': self.doctor_id,
            'appointment_id': self.appointment_id,
            'record_type': self.record_type.value,
            'title': self.title,
            'description': self.description,
            'record_date': self.record_date.isoformat(),
            'chief_complaint': self.chief_complaint,
            'history_of_present_illness': self.history_of_present_illness,
            'physical_examination': self.physical_examination,
            'assessment': self.assessment,
            'plan': self.plan,
            'blood_pressure_systolic': self.blood_pressure_systolic,
            'blood_pressure_diastolic': self.blood_pressure_diastolic,
            'heart_rate': self.heart_rate,
            'temperature': self.temperature,
            'weight': self.weight,
            'height': self.height,
            'file_url': self.file_url,
            'file_name': self.file_name,
            'file_size': self.file_size,
            'file_type': self.file_type,
            'is_confidential': self.is_confidential,
            'is_shared_with_patient': self.is_shared_with_patient,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
    
    def to_dict_with_details(self):
        """Convert medical record to dictionary with doctor details"""
        result = self.to_dict()
        if self.doctor:
            result['doctor'] = self.doctor.to_dict_public()
        return result
    
    def __repr__(self):
        return f'<MedicalRecord {self.id} - {self.title}>'


class Prescription(db.Model):
    __tablename__ = 'prescriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    medical_record_id = db.Column(db.Integer, db.ForeignKey('medical_records.id'), nullable=False)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=False)
    
    # Medication details
    medication_name = db.Column(db.String(200), nullable=False)
    dosage = db.Column(db.String(100), nullable=False)  # e.g., "10mg"
    frequency = db.Column(db.String(100), nullable=False)  # e.g., "twice daily"
    duration = db.Column(db.String(100), nullable=False)  # e.g., "7 days"
    instructions = db.Column(db.Text, nullable=True)  # e.g., "Take with food"
    
    # Prescription details
    prescribed_date = db.Column(db.Date, nullable=False)
    start_date = db.Column(db.Date, nullable=True)
    end_date = db.Column(db.Date, nullable=True)
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    is_completed = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert prescription to dictionary"""
        return {
            'id': self.id,
            'medical_record_id': self.medical_record_id,
            'patient_id': self.patient_id,
            'doctor_id': self.doctor_id,
            'medication_name': self.medication_name,
            'dosage': self.dosage,
            'frequency': self.frequency,
            'duration': self.duration,
            'instructions': self.instructions,
            'prescribed_date': self.prescribed_date.isoformat(),
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'is_active': self.is_active,
            'is_completed': self.is_completed,
            'created_at': self.created_at.isoformat()
        }
    
    def __repr__(self):
        return f'<Prescription {self.medication_name} - {self.dosage}>'

