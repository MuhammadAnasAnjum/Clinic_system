import React from 'react';

const MobileContainer = ({ children, showStatusBar = true }) => {
  return (
    <div className="mobile-container">
      {showStatusBar && (
        <div className="status-bar">
          <span>9:41</span>
          <span>📶 📶 📶 🔋</span>
        </div>
      )}
      <div className="flex-1 overflow-hidden">
        {children}
      </div>
    </div>
  );
};

export default MobileContainer;

