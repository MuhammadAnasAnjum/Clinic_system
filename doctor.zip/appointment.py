from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from enum import Enum

db = SQLAlchemy()

class AppointmentStatus(Enum):
    SCHEDULED = "scheduled"
    CONFIRMED = "confirmed"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    NO_SHOW = "no_show"

class AppointmentType(Enum):
    IN_PERSON = "in_person"
    TELEMEDICINE = "telemedicine"
    FOLLOW_UP = "follow_up"
    EMERGENCY = "emergency"

class PaymentStatus(Enum):
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    REFUNDED = "refunded"

class Appointment(db.Model):
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=False)
    
    # Appointment details
    appointment_date = db.Column(db.Date, nullable=False)
    appointment_time = db.Column(db.Time, nullable=False)
    appointment_type = db.Column(db.Enum(AppointmentType), nullable=False, default=AppointmentType.IN_PERSON)
    duration_minutes = db.Column(db.Integer, default=30)
    
    # Location (for in-person appointments)
    clinic_name = db.Column(db.String(100), nullable=True)
    clinic_address = db.Column(db.String(200), nullable=True)
    
    # Status and tracking
    status = db.Column(db.Enum(AppointmentStatus), nullable=False, default=AppointmentStatus.SCHEDULED)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Patient information
    chief_complaint = db.Column(db.Text, nullable=True)  # Why patient is visiting
    symptoms = db.Column(db.Text, nullable=True)
    notes = db.Column(db.Text, nullable=True)  # Additional notes from patient
    
    # Payment information
    consultation_fee = db.Column(db.Float, nullable=False)
    payment_status = db.Column(db.Enum(PaymentStatus), nullable=False, default=PaymentStatus.PENDING)
    payment_method = db.Column(db.String(50), nullable=True)  # e.g., "credit_card", "jazzcash", "easypaisa"
    payment_transaction_id = db.Column(db.String(100), nullable=True)
    payment_date = db.Column(db.DateTime, nullable=True)
    
    # Telemedicine specific
    video_call_link = db.Column(db.String(500), nullable=True)
    video_call_room_id = db.Column(db.String(100), nullable=True)
    
    # Cancellation
    cancelled_at = db.Column(db.DateTime, nullable=True)
    cancellation_reason = db.Column(db.Text, nullable=True)
    cancelled_by = db.Column(db.String(20), nullable=True)  # "patient" or "doctor"
    
    # Relationships - using string references to avoid circular imports
    medical_record = db.relationship('MedicalRecord', backref='appointment', uselist=False, lazy=True)
    
    def to_dict(self):
        """Convert appointment to dictionary"""
        return {
            'id': self.id,
            'patient_id': self.patient_id,
            'doctor_id': self.doctor_id,
            'appointment_date': self.appointment_date.isoformat(),
            'appointment_time': self.appointment_time.strftime('%H:%M'),
            'appointment_type': self.appointment_type.value,
            'duration_minutes': self.duration_minutes,
            'clinic_name': self.clinic_name,
            'clinic_address': self.clinic_address,
            'status': self.status.value,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'chief_complaint': self.chief_complaint,
            'symptoms': self.symptoms,
            'notes': self.notes,
            'consultation_fee': self.consultation_fee,
            'payment_status': self.payment_status.value,
            'payment_method': self.payment_method,
            'payment_transaction_id': self.payment_transaction_id,
            'payment_date': self.payment_date.isoformat() if self.payment_date else None,
            'video_call_link': self.video_call_link,
            'video_call_room_id': self.video_call_room_id,
            'cancelled_at': self.cancelled_at.isoformat() if self.cancelled_at else None,
            'cancellation_reason': self.cancellation_reason,
            'cancelled_by': self.cancelled_by
        }
    
    def to_dict_with_details(self):
        """Convert appointment to dictionary with patient and doctor details"""
        result = self.to_dict()
        if self.patient:
            result['patient'] = self.patient.to_dict_safe()
        if self.doctor:
            result['doctor'] = self.doctor.to_dict_public()
        return result
    
    def __repr__(self):
        return f'<Appointment {self.id} - {self.appointment_date} {self.appointment_time}>'


class AppointmentSlot(db.Model):
    __tablename__ = 'appointment_slots'
    
    id = db.Column(db.Integer, primary_key=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=False)
    
    # Slot details
    slot_date = db.Column(db.Date, nullable=False)
    slot_time = db.Column(db.Time, nullable=False)
    duration_minutes = db.Column(db.Integer, default=30)
    
    # Availability
    is_available = db.Column(db.Boolean, default=True)
    is_blocked = db.Column(db.Boolean, default=False)  # Manually blocked by doctor
    block_reason = db.Column(db.String(200), nullable=True)
    
    # Appointment type availability
    allows_in_person = db.Column(db.Boolean, default=True)
    allows_telemedicine = db.Column(db.Boolean, default=True)
    
    # Clinic information (for in-person slots)
    clinic_name = db.Column(db.String(100), nullable=True)
    clinic_address = db.Column(db.String(200), nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert appointment slot to dictionary"""
        return {
            'id': self.id,
            'doctor_id': self.doctor_id,
            'slot_date': self.slot_date.isoformat(),
            'slot_time': self.slot_time.strftime('%H:%M'),
            'duration_minutes': self.duration_minutes,
            'is_available': self.is_available,
            'is_blocked': self.is_blocked,
            'block_reason': self.block_reason,
            'allows_in_person': self.allows_in_person,
            'allows_telemedicine': self.allows_telemedicine,
            'clinic_name': self.clinic_name,
            'clinic_address': self.clinic_address,
            'created_at': self.created_at.isoformat()
        }
    
    def __repr__(self):
        return f'<AppointmentSlot {self.slot_date} {self.slot_time}>'

